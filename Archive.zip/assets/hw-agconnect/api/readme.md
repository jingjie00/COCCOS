# @hw-agconnect/api

**This package cannot be used directly, and can only be used through another AppGallery Connect package.**
