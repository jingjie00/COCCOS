# @hw-agconnect/instance

## Overview
This package initializes AppGallery Connect services. For initialization, find your project information on the AppGallery Connect console and copy it to the following code: 
```js
//The agConnectConfig is your project config info.
agconnect.instance().configInstance(agConnectConfig);
```
