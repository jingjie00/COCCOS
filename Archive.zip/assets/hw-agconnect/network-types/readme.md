# @hw-agconnect/network-types

**This package cannot be used directly, and can only be used through the network package.**
