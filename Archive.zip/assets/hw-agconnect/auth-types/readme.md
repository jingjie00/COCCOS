# @hw-agconnect/auth-types

**This package cannot be used directly, and can only be used through the auth package.**
